<template>
  <div class="home">
    <!-- <img alt="Vue logo" src="../assets/logo.png"> -->
    <!-- <HelloWorld msg="Welcome to Your Vue.js App"/> -->
    <vue-ueditor-wrap
      v-model="msg"
      :config="ueConfig"
      editor-id="editor-demo-01"
    ></vue-ueditor-wrap>
    {{ msg }}
  </div>
</template>

<script>
// @ is an alias to /src

export default {
  data () {
    return {
      msg: '666',
      ueConfig: {
        toolbars: [
          [
            'undo', // 撤销
            'bold', // 加粗
            'indent', // 首行缩进
            'italic', // 斜体
            'underline', // 下划线
            'strikethrough', // 删除线
            'subscript', // 下标
            'fontborder', // 字符边框
            'superscript', // 上标
            'formatmatch', // 格式刷
            'fontfamily', // 字体
            'fontsize', // 字号
            'justifyleft', // 居左对齐
            'justifycenter', // 居中对齐
            'justifyright', // 居右对齐
            'justifyjustify', // 两端对齐
            'insertorderedlist', // 有序列表
            'insertunorderedlist', // 无序列表
            'lineheight' // 行间距
          ]
        ],
        fontfamily: [
          { label: '', name: 'songti', val: '宋体,SimSun' },
          { label: '仿宋', name: 'fangsong', val: '仿宋,FangSong' },
          {
            label: '仿宋_GB2312',
            name: 'fangsong',
            val: '仿宋_GB2312,FangSong'
          },
          { label: '', name: 'kaiti', val: '楷体,楷体_GB2312, SimKai' },
          { label: '', name: 'yahei', val: '微软雅黑,Microsoft YaHei' },
          { label: '', name: 'heiti', val: '黑体, SimHei' },
          { label: '', name: 'lishu', val: '隶书, SimLi' },
          { label: '', name: 'andaleMono', val: 'andale mono' },
          { label: '', name: 'arial', val: 'arial, helvetica,sans-serif' },
          { label: '', name: 'arialBlack', val: 'arial black,avant garde' },
          { label: '', name: 'comicSansMs', val: 'comic sans ms' },
          { label: '', name: 'impact', val: 'impact,chicago' },
          { label: '', name: 'timesNewRoman', val: 'times new roman' }
        ],
        // 初始容器高度
        initialFrameHeight: 300,
        // 初始容器宽度
        initialFrameWidth: '100%',
        // 上传文件接口
        enableAutoSave: false,
        elementPathEnable: false,
        wordCount: false
      }
    }
  },
  created () {
    // 更多 UEditor 配置，参考 http://fex.baidu.com/ueditor/#start-config
    this.ueConfig = {
      // 访问 UEditor 静态资源的根路径，可参考 https://hc199421.gitee.io/vue-ueditor-wrap/#/faq
      UEDITOR_HOME_URL: '/UEditor/',
      // 服务端接口（这个地址是我为了方便各位体验文件上传功能搭建的临时接口，请勿在生产环境使用！！！）
      serverUrl: '//ueditor.szcloudplus.com/cos'
    }
  },
  name: 'Home',
  components: {}
}
</script>
